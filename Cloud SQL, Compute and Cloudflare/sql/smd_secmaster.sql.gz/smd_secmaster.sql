CREATE TABLE IF NOT EXISTS exchange (
    id SERIAL PRIMARY KEY,
    abbrev TEXT NOT NULL,
    name TEXT NOT NULL,
    currency VARCHAR(64) NULL,
    created_date TIMESTAMP NOT NULL,
    last_updated_date TIMESTAMP NOT NULL
    );
CREATE TABLE IF NOT EXISTS data_vendor (
    id SERIAL PRIMARY KEY,
    name TEXT UNIQUE NOT NULL,
    website_url VARCHAR(255) NULL,
    created_date TIMESTAMP NOT NULL,
    last_updated_date TIMESTAMP NOT NULL
    );
CREATE TABLE IF NOT EXISTS symbol (
    id SERIAL PRIMARY KEY,
    exchange_id integer NULL,
    data_vendor_id integer NULL,
    ticker TEXT NOT NULL,
    instrument TEXT NOT NULL,
    name TEXT NULL,
    sector TEXT NULL,
    currency VARCHAR(64) NULL,
    shortable BOOL NULL,
    easy_to_borrow BOOL NULL,
    marginable BOOL NULL,
    tradable BOOL NULL,
    status TEXT NULL,
    created_date TIMESTAMP NOT NULL,
    last_updated_date TIMESTAMP NOT NULL,
    FOREIGN KEY (data_vendor_id) REFERENCES data_vendor(id),
    FOREIGN KEY (exchange_id) REFERENCES exchange(id)
    );
CREATE TABLE IF NOT EXISTS daily_data (
    id SERIAL PRIMARY KEY,
    stock_id INTEGER NOT NULL,
    created_date TIMESTAMP NOT NULL,
    last_updated_date TIMESTAMP NOT NULL,
    date_price TIMESTAMP,
    open_price NUMERIC,
    high_price NUMERIC,
    low_price NUMERIC,
    close_price NUMERIC,
    volume BIGINT,
    FOREIGN KEY (stock_id) REFERENCES symbol(id)
    );
 CREATE TABLE IF NOT EXISTS minute_data (
    id SERIAL PRIMARY KEY,
    stock_id INTEGER NOT NULL,
    created_date TIMESTAMP NOT NULL,
    last_updated_date TIMESTAMP NOT NULL,
    date_price TIMESTAMP,
    open_price NUMERIC,
    high_price NUMERIC,
    low_price NUMERIC,
    close_price NUMERIC,
    volume BIGINT,
    FOREIGN KEY (stock_id) REFERENCES symbol(id)
    );